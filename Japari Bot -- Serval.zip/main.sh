pip install amino.py
pip install Config
clear
python bmoniski.py